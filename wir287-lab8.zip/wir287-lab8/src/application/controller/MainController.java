package application.controller;

import application.model.Calculator;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class MainController implements EventHandler<ActionEvent> {
	
	@FXML
	private Label output;
	private Calculator calc;
	
	public MainController() {
		super();
		this.calc = new Calculator();
	}
	

	@Override
	public void handle(ActionEvent event) {
		Button b = (Button)event.getSource();
		this.calc.update( b.getText() );
		this.output.setText( calc.getValue());
		
	
 }
	// clear button handler 
	public void processClear(ActionEvent event) {
		Button b = (Button)event.getSource();
		output.setText("0.0");		
	}
	// Power button handler 
	public void power(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	// Square root button handler 
	public void squareRoot(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	
	// handler for natural log 
	public void naturalLog(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	
	// handler for inverse 
	public void inverse(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	
	// handler for Sin 
	public void sin(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	// handler for cos 
	public void cos(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	
	// handler for tan 
	public void tan(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
	// handler for log 
	public void log(ActionEvent event) {
		Button b = (Button)event.getSource();
		calc.update(b.getText());
	}
}