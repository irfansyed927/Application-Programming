import java.util.*;

public class SortingThread implements Runnable {
    
    int name;
    int[] arr;
    SortingBuffer buffer;
    
    public SortingThread(int name, int[] arr, SortingBuffer buffer) {
        this.name = name;
        this.arr = arr;
        this.buffer = buffer;
        for(int n = 0; n < arr.length; n++) {
            System.out.println(name + " unsynchronized " + arr[n]);
        }
    }
    
    @Override
    public void run() {
        Arrays.sort(arr);
        for(int i = 0; i < arr.length; i++) {
            try{
                buffer.waitUntilMinimum(name, arr[i]);
                System.out.println(name + " synchronized " + arr[i]);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
        }
        buffer.finished(name);
    }
}
