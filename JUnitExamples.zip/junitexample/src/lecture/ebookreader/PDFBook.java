package lecture.ebookreader;

public class PDFBook extends EBook{
	
	public PDFBook( String title, String author ) {
		super(title,author);
	}
	
	@Override
	public String getFileType() {
		return "pdf";
	}

}
