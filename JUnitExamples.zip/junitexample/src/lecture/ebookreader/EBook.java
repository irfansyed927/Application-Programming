package lecture.ebookreader;


public abstract class EBook {

	private String title;
	private String author;
	private int year;
	private int bookmarkedPage;
	
	public EBook( String title, String author ) {
		this.title = title;
		this.author = author;
		this.bookmarkedPage = 1;
	}
	
	
	public abstract String getFileType();
	
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getBookmark() {
		return this.bookmarkedPage;
	}
	public void setBookmark(int page) {
		this.bookmarkedPage = page;
	}
}