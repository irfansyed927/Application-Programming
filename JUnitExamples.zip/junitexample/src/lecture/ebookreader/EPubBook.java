package lecture.ebookreader;

public class EPubBook extends EBook{

	public EPubBook( String title, String author ) {
		super(title,author);
	}
	
	@Override
	public String getFileType() {
		return "epub";
	}

}
