package lecture.ebookreader;


import java.util.ArrayList;

public class Library {

	private ArrayList<EBook> books;
	
	
	public Library() {
		this.books = new ArrayList<EBook>();
	}
	
	
	
	public int getLibrarySize() {
		return this.books.size();
	}
	
	public ArrayList<EBook> getBookList(){
		return this.books;
	}
	
	public void addBook( EBook book ) {
		this.books.add( book );
	}
	
	public void deleteBook( EBook book ) {
		for( int i=0; i<books.size(); i++ ) {
			EBook b = books.get(i);
			if( b.getTitle().equals(book.getTitle()) && b.getAuthor().equals(book.getAuthor()) ) {
				this.books.remove(i);
				return;
			}
		}
	}	
}