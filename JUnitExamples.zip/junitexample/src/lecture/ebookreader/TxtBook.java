package lecture.ebookreader;

public class TxtBook extends EBook {

	public TxtBook( String title, String author ) {
		super(title,author);
	}
	
	@Override
	public String getFileType() {
		return "txt";
	}	
}
