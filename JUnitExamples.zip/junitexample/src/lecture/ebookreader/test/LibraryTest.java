package lecture.ebookreader.test;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import lecture.ebookreader.*;

public class LibraryTest {
	
	Library library;

	@Before
	public void setUp() throws Exception {
		EBook book1  = new TxtBook( "Effective Java", "Joshua Bloch" );
		EBook book2  = new PDFBook( "Java SE8 For Programmers", "Paul Deitel and Harvey Deitel" );
		this.library = new Library();
		this.library.addBook( book1 );
		this.library.addBook( book2 );
	}

	@After
	public void tearDown() throws Exception {
		library = null;
	}

	@Test
	public final void testGetLibrarySize() {
		assert ( library.getLibrarySize()==2 ) : "Library size method, 2!=" + library.getLibrarySize();
	}

	@Test
	public final void testGetBookList() {
		assert ( library.getBookList() instanceof ArrayList ) : "Get book list incorrect type"; 
		assert ( library.getBookList() != null ) : "Get book list - null"; 
	}

	@Test
	public final void testAddBook() {
		EBook book3  = new PDFBook( "Atlas Shrugged", "Ayn Rand" );
		library.addBook(book3);
		assert ( library.getBookList().size()==3 ) : "Library add book, 3!=" + library.getLibrarySize(); 
		library.deleteBook(book3);
	}

	@Test
	public final void testDeleteBook() { 
		EBook b = new TxtBook( "Atlas Shrugged", "Ayn Rand" );
		library.addBook( b );
		library.deleteBook( b );
		assert ( library.getBookList().size()==2 ) : "Library delete book, 2!=" + library.getLibrarySize();	
	}
}