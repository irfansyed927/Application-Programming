package test;

import static org.junit.Assert.*;
import org.junit.Test;
import core.GradeBook;

public class TestGradeBook {
    /**
     * average method test case using null grade array. The correct behavior is
     * a runtime error.
     */
    @Test
    public void testAverageNull() {
        GradeBook gb = new GradeBook("test", null);
        boolean nullError = false;
        try {
            gb.getAverage();
        } catch (NullPointerException e) {
            nullError = true;
        }
        assertTrue("should be a NullPointerException", nullError);
    }

    /**
     * average method test case using 10 elements. The correct behavior is the
     * average of the numbers plus or minus roundoff.
     */
    @Test
    public void testAverage10Element() {
        int[] grades = { 87, 99, 96, 99, 86, 96, 77, 95, 70, 88 };
        GradeBook gb = new GradeBook("test", grades);
        double average = 0;
        for (int grade : grades) {
            average += grade;
        }
        average /= grades.length;
        assertEquals("10 element test failed", average, gb.getAverage(),
                0.000001);
    }
}
