package lab1package;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Lab 1 task is to read the tokens from a file and print out three values 
 * The number of tokens
 * the number of tokens that are not numbers 
 * The sum of the numbers 
 * @author iffi_
 *
 */

public class lab1 {

public static void main(String args[]) {

	/**
	 * Reading the file 
	 */
	Scanner in = null;
	try {
		in = new Scanner(new File ("data.txt"));
	} catch (FileNotFoundException e) {
		System.err.println("Failed to open data.txt");
		System.exit(1);
	}
	 double s = 0.0; // declaring the double to 0 
	 double n = 0.0; // declaring double to 0 
	 double sum = 0.0 ; // declaring the sum = 0  
	
	/**
	 * Reading all the tokens from the file using hasNext 
	 * and converting a string to double if any 
	 */
	while (in.hasNext()) {
		String token = in.next();
		
		if( new Scanner(token).hasNextDouble()) {
			//System.out.println("It is a double!");
			double d = Double.parseDouble(token);
			s++; 
			sum += d;
		} else {
			//System.out.println("It is not a double");
			n++;
		}
	}
		
		System.out.print(s);
		System.out.print(" ");
		System.out.print(n);
		System.out.print(" ");
		System.out.print(sum);
		in.close();
	
 }
}
